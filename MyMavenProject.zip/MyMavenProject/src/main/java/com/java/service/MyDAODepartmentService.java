package com.java.service;
import java.util.List;

import java.util.ArrayList;

import javax.servlet.jsp.ErrorData;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.dao.DepartmentDAOImpl;
import com.java.entity.Department;
import com.java.myexceptions.*;


/*
 * 
 * DB POJO DAO
 * 1  2    3		DB - DAO
 * 					|
 * 4			REST WEB Service
 * 					|
 * 5			Controller - ServletContainer
 * 					|
 * 	6			ANGULAR - typescript
 * 
 * 
 * 
 * 
 */
@Path("/deptDAOservice")
public class MyDAODepartmentService {
	
	DepartmentDAOImpl deptDao = new DepartmentDAOImpl();
	
	public MyDAODepartmentService() {
		// TODO Auto-generated constructor stub
		System.out.println("MyDepartmentService() ctor.. is ready...");
	}
	
	@GET
	@Path("/getDepts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Department> getAllDepartments() {
		System.out.println("/getDepts");
		try {
			return deptDao.selectDepartments();
		} catch (DepartmentTableEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@GET
	@Path("/getDept/{deptno}")
	@Produces(MediaType.APPLICATION_JSON)
	public Department getSingleDepartment(@PathParam("deptno") int x) throws DepartmentNotFoundException
	{
		System.out.println("/getDept");
		Department tempDept=null;
		try {
			tempDept = deptDao.selectDepartment(x);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw e;
		}		
		return tempDept;
	}
	
	@GET
	@Path("/getDept2/{deptno}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getSingleDepartment2(@PathParam("deptno") int x) throws DepartmentNotFoundException
	{
		Response response = null;
		System.out.println("/getDept2");
		Department tempDept=null;
		try {
			tempDept = deptDao.selectDepartment(x);
			response = Response.ok().entity(tempDept).build();
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			 response =  Response.serverError().entity(e.getMessage()).build();
		}		
		return response;
	}
	
	@POST
	@Path("/addDept")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addDepartment(Department deptObj) {
		System.out.println("/addDept");
		try {
			deptDao.insertDepartment(deptObj);
		} catch (DepartmentAreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return Response.status(201).build();
		
	}
	
	@PUT
	@Path("/updateDept")
	@Produces(MediaType.APPLICATION_JSON)
	public Department updateDepartment(Department deptToModify) {
		System.out.println("/updateDept");
		try {
			deptDao.updateDepartment(deptToModify);
		} catch (DepartmentNotFoundException | DepartmentUpdateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deptToModify;
	}
	
	@DELETE
	@Path("/deleteDept/{deptno}")
	public Response deleteDepartment(@PathParam("deptno") int x) {
		System.out.println("/deleteDept");	
		try {
			deptDao.deleteDepartment(x);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Response.status(201).build();
		
	}

}


