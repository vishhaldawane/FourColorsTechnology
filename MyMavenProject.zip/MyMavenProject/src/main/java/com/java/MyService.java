package com.java;
import javax.ws.rs.GET;
import javax.ws.rs.Path; //REST REepsentational State Transfer
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
// http://localhost:8080/MyMavenProject/rest/myserv/greet1
@Path("/myserv")//logical uri
public class MyService { //no extends HttpServlet
	public MyService() {
		System.out.println("MyService()... ctor...");
	}	
	@GET
	@Path("/greet1") // + another logical uri
	@Produces(MediaType.APPLICATION_JSON)
	public String sayHi() { //no do get
	  return "Hi to Web Services1";
	}
	@GET
	@Path("/greet2")
	@Produces(MediaType.APPLICATION_JSON)
	public String sayHello() { //no do get
	  return "Hello to Web Services2";
	}
	@GET
	@Path("/greet3")
	@Produces(MediaType.APPLICATION_JSON)
	public String sayGreet() { //no do get
	  return "Greet to Web Services3";
	}
	
}
