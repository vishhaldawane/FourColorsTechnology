package com.java.myexceptions;

public class DepartmentTableEmptyException extends /*Runtime*/Exception {

	public DepartmentTableEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
