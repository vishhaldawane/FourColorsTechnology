package com.java.myexceptions;

public class DepartmentUpdateException extends /*Runtime*/Exception {

	public DepartmentUpdateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
