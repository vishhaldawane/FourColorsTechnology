package com.java.dao;

import java.util.List;

import com.java.entity.Department;

//Create Read/ReadAll Update Delete

public interface DepartmentDAO { //2. POJO crud interface
	void 			  insertDepartment(Department deptObj);
	Department  	  selectDepartment(int deptNumber);
	List<Department>  selectDepartments();
	void updateDepartment(Department deptObj);
	void deleteDepartment(int deptNumber);
}
