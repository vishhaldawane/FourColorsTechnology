package com.java;
import java.util.List;

import java.util.ArrayList;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



/*
 * 
 * DB POJO DAO
 * 1  2    3		DB - DAO
 * 					|
 * 4			REST WEB Service
 * 					|
 * 5			Controller - ServletContainer
 * 					|
 * 	6			ANGULAR - typescript
 * 
 * 
 * 
 * 
 */

// http://localhost/deptDAOservice/getDepts

@CrossOrigin(origins = "*", methods = {RequestMethod.DELETE,RequestMethod.PUT,RequestMethod.POST,RequestMethod.GET })
@RestController
@RequestMapping("/deptDAOservice")
public class MyDAODepartmentService {
	
	DepartmentDAOImpl deptDao = new DepartmentDAOImpl();
	
	public MyDAODepartmentService() {
		// TODO Auto-generated constructor stub
		System.out.println("MyDepartmentService() ctor.. is ready...");
	}
	
	
	@GetMapping
	@RequestMapping("/getDepts")
	public List<Department> getAllDepartments() {
		System.out.println("/getDepts");
		try {
			return deptDao.selectDepartments();
		} catch (DepartmentTableEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping
	@RequestMapping(path="/getDept/{deptno}")
	public Department getSingleDepartment(@PathVariable("deptno") int deptno) throws DepartmentNotFoundException
	{
		System.out.println("/getDept");
		Department tempDept=null;
		try {
			tempDept = deptDao.selectDepartment(deptno);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw e;
		}		
		return tempDept;
	}
	
	@GetMapping
	@RequestMapping(path="/getDept2/{deptno}")
	public Response getSingleDepartment2(@PathVariable("deptno") int x) 
	{
		Response response = null;
		System.out.println("/getDept2");
		Department tempDept=null;
		try {
			tempDept = deptDao.selectDepartment(x);
			response = Response.ok().entity(tempDept).build();
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			 response =  Response.serverError().entity(e.getMessage()).build();
		}		
		return response; // java script<--type scripting
	}
	
	@PostMapping
	@RequestMapping(path="/addDept")

	public Response addDepartment(Department deptObj) {
		System.out.println("/addDept");
		try {
			deptDao.insertDepartment(deptObj);
		} catch (DepartmentAreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return Response.status(201).build();
		
	}
	
	@PutMapping
	@RequestMapping(path="/updateDept")
	
	public Department updateDepartment(Department deptToModify) {
		System.out.println("/updateDept");
		try {
			deptDao.updateDepartment(deptToModify);
		} catch (DepartmentNotFoundException e) {
			e.printStackTrace();
		}
		
		catch(DepartmentUpdateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deptToModify;
	}
	
	@DeleteMapping
	@RequestMapping(path="/deleteDept/{deptno}")
	public String deleteDepartment(@PathVariable("deptno") int x) {
		String response = null;
		
		System.out.println("/deleteDept");	
		try {
			deptDao.deleteDepartment(x);
			response =  "Deleted";
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response = "Not found";
		}
		return response;
		
	}

}

/*
 import { HttpClient } from '@angular/common/http';
 HttpClient
 
   FormsModule,
    HttpClientModule
    
 
 getAllFriendsFromSpring() : Observable<Friend[]> {
      console.log('getting all friends from spring');
      //the below line would talk to Spring's controller -> FriendController
      return this.myHttp.get<Friend[]>("http://localhost:8080/friend/getAllFromDB");
    //                                  https://jsonplaceholder.typicode.com/users
    }

  addFriendToSpring(newFriend: Friend) : Observable<Friend> {
    console.log('adding a friend to spring');
    console.log(newFriend.friendId);
    console.log(newFriend.friendName);
    
    //the below line would talk to Spring's controller -> FriendController
    return this.myHttp.post<Friend>("http://localhost:8080/friend/addFriend/",newFriend);
  }
  
  --
  
  import { Component, OnInit } from '@angular/core';
import { Friend } from '../Friend';
import { FriendService } from '../friend.service';

@Component({
  selector: 'app-friend',
  templateUrl: './friend.component.html',
  styleUrls: ['./friend.component.css']
})
export class FriendComponent implements OnInit {

  constructor(private fs: FriendService) { }

  theFriend: Friend = new Friend();

  allFriends : Friend[]|undefined; //INITIALLY BLANK ARRAY
  
  ngOnInit(): void {
  }
  showAllFriends() {//invoked on button
    console.log("showing all the friends on button click");
    this.fs.getAllFriendsFromSpring().subscribe(
      (data: Friend[])=> //srping data is pushed into this data variable
      {
        this.allFriends = data; //assign data to allFriends so that html can fetch it in tr td tags
        console.log(this.allFriends);
      }, 
      (err) => {
        console.log(err);
      }
    ); 
    
  }
//localhost:4200

addFriend() {
  console.log('adding a friend');
  this.fs.addFriendToSpring(this.theFriend).subscribe(
    (data: Friend)=> //srping data is pushed into this data variable
    {
      this.theFriend = data; //assign data to allFriends so that html can fetch it in tr td tags
      console.log(this.theFriend);
    }, 
    (err) => {
      console.log(err);
    }
  ); 
}

}


  
 */


