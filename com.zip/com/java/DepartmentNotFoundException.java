package com.java;

public class DepartmentNotFoundException extends /*Runtime*/Exception {

	public DepartmentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
