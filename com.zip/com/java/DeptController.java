package com.java;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/dept")
public class DeptController {
	
	@RequestMapping("/hi") // http://localhost:8080/department/hi
	public String greet() {
		
		return "Welcome to Spring MVC";
	}
	@RequestMapping("/bye")// http://localhost:8080/department/bye
	public String seeYouAgain() {
		
		return "Bye buy tata ....see u soon..khatam tata bue gaya .... ";
	}
	
	@RequestMapping("/fly")// http://localhost:8080/department/bye
	public Flight flightDetail() {
		Flight fliObj = new Flight(101,"AirFrance","Mumbai","Paris");
		return fliObj;
	}
	
	@RequestMapping("/flys")// http://localhost:8080/department/bye
	public List<Flight> flightDetails() {
		Flight fliObj1 = new Flight(101,"AirFrance","Mumbai","Paris");
		Flight fliObj2 = new Flight(102,"American Airlines","Mumbai","New York");
		Flight fliObj3 = new Flight(103,"British Airways","Mumbai","London");

		List<Flight> flightList = new ArrayList<Flight>();
		flightList.add(fliObj1);
		flightList.add(fliObj2);
		flightList.add(fliObj3);
		
		return flightList;
	}
	
	
	
	
	
}
class Flight {
	private int flightNumber;
	private String flightName;
	private String source;
	private String destination;
	
	
	
	public Flight(int flightNumber, String flightName, String source, String destination) {
		super();
		this.flightNumber = flightNumber;
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
	}
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
}

/*
 * 
 
 	http://localhost:8080/banking/accounts/savings/dele
	banking
		|
		---------accounts
		|			|
		|			-------
		|					|
		|					savings
		|						|
		|						get
		|	
		---------transfer
		|
		---------statement

*/


