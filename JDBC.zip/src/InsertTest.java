import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



/*

  
  create table dept_fc
  (
    deptno int primary key,
    deptname varchar(20),
    deptloc  varchar(20)
  );
  
  insert into dept_fc values (10,'IT','Mumbai');
  insert into dept_fc values (20,'Sales','Delhi');
  insert into dept_fc values (30,'QMS','Pune');
  insert into dept_fc values (40,'Testing','Chennai');
  
  SELECT * FROM DEPT_FC;
  
 */


public class InsertTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. load teh driver
		
		try {
			System.out.println("Trying to register the driver...");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registerd....");
			
			System.out.println("Trying to acquire the connection with the database....");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			System.out.println("Connected to the DB : "+conn);
			
			Scanner scan1 = new Scanner(System.in);
			Scanner scan2 = new Scanner(System.in);
			Scanner scan3 = new Scanner(System.in);
			
			System.out.println("Enter new dept number : ");
			int newDeptno = scan1.nextInt();
			
			System.out.println("Enter new dept name   : ");
			String newDeptName = scan2.next();

			System.out.println("Enter new dept loc    : ");
			String newDeptLoc = scan3.next();
			
			PreparedStatement pst = conn.prepareStatement("insert into dept_Fc values (?,?,?)");
			pst.setInt(1, newDeptno);
			pst.setString(2, newDeptName);
			pst.setString(3, newDeptLoc);
			
			System.out.println("PreparedStatement made "+pst);
			
			int row = pst.executeUpdate();
			System.out.println(row+" row(s) inserted.....");
			
			pst.close();
			conn.close();
			System.out.println("DB resources are closed.....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
