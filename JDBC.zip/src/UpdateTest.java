import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



/*

  
  create table dept_fc
  (
    deptno int primary key,
    deptname varchar(20),
    deptloc  varchar(20)
  );
  
  insert into dept_fc values (10,'IT','Mumbai');
  insert into dept_fc values (20,'Sales','Delhi');
  insert into dept_fc values (30,'QMS','Pune');
  insert into dept_fc values (40,'Testing','Chennai');
  
  SELECT * FROM DEPT_FC;
  
 */


public class UpdateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. load teh driver
		
		try {
			System.out.println("Trying to register the driver...");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registerd....");
			
			System.out.println("Trying to acquire the connection with the database....");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			System.out.println("Connected to the DB : "+conn);
			
			Scanner scan1 = new Scanner(System.in);
			Scanner scan2 = new Scanner(System.in);
			Scanner scan3 = new Scanner(System.in);
			
			System.out.println("Enter EXISTING dept number : ");
			int existingDeptno = scan1.nextInt();
			
			System.out.println("For which enter the MODIFYING dept name   : ");
			String modifiedDeptName = scan2.next();

			System.out.println("For which enter the MODIFYING dept loc    : ");
			String modifiedDeptLoc = scan3.next();
			
			PreparedStatement pst = conn.prepareStatement("update dept_Fc set deptname=?, deptloc=? where deptno=?");
			pst.setInt(3, existingDeptno);
			pst.setString(1, modifiedDeptName);
			pst.setString(2, modifiedDeptLoc);
			
			System.out.println("PreparedStatement made "+pst);
			
			int row = pst.executeUpdate();
			System.out.println(row+" row(s) updated.....");
			
			pst.close();
			conn.close();
			System.out.println("DB resources are closed.....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
