import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



/*

  
  create table dept_fc
  (
    deptno int primary key,
    deptname varchar(20),
    deptloc  varchar(20)
  );
  
  insert into dept_fc values (10,'IT','Mumbai');
  insert into dept_fc values (20,'Sales','Delhi');
  insert into dept_fc values (30,'QMS','Pune');
  insert into dept_fc values (40,'Testing','Chennai');
  
  SELECT * FROM DEPT_FC;
  
 */


public class DeleteTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. load teh driver
		
		try {
			System.out.println("Trying to register the driver...");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registerd....");
			
			System.out.println("Trying to acquire the connection with the database....");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			System.out.println("Connected to the DB : "+conn);
			
			Scanner scan1 = new Scanner(System.in);
			
			
			System.out.println("Enter EXISTING dept number to delete : ");
			int existingDeptno = scan1.nextInt();
			
			
			PreparedStatement pst = conn.prepareStatement("delete from dept_Fc where deptno=?");
			pst.setInt(1, existingDeptno);
		
			
			System.out.println("PreparedStatement made "+pst);
			
			int row = pst.executeUpdate();
			System.out.println(row+" row(s) deleted.....");
			
			pst.close();
			conn.close();
			System.out.println("DB resources are closed.....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
