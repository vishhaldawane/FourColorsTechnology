
public class Notes {

}
/*
 * 
 *
	HttpSession cart = request.getSession();
	
						hashtable
						-------------
						key					value
						sessionid(24digit)	|
						---------------------------------------------
											Elect   Cloth   Check
						c1					1tv/1vd 1t/1j = 4
						---------------------------------------------
						c2					2tv/2vd 0t/2j = 6
						---------------------------------------------
						c3					3tv/2vd 3t/0j = 8
						---------------------------------------------

						..
						..

				Server	----ElectServ - shop1
				|		----ClothServ - shop2
				|		----CheckServ - billing counter
				|
				|
		-------------------------------
			|		|		|	|	|
			c1		c2		c3	c4	c5 ...
			|		|		 |
Elect.html 1tv/1vd	2tv/2vd 3tv/2vd
Cloth.html 1t/1j	0t/2j	3t/0j
Check.html 4items	6items	9items
			Cart	Cart	Cart
			




*/