package com.math;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ArithmeticTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin main...");
		
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		
		try {
			System.out.println("Begin of try...");
			
			System.out.println("Enter numerator   : ");
			int num1 = scan1.nextInt();
			
			System.out.println("Enter denominator : ");
			int num2 = scan1.nextInt();

		
			MyCalculator myCalci = new MyCalculator();
			System.out.println("myCalci object is created.....");
			
			myCalci.divide(num1,num2);
			
			System.out.println("End of try...");
				
		}
		
		catch(InputMismatchException imEx) {
			System.out.println("Problem 1 : "+imEx);
		}
		catch(ArithmeticException arithEx) {
			System.out.println("Problem 2 : "+arithEx);		
		}
		catch(RuntimeException runEx) {
			System.out.println("Problem 3 : "+runEx);		
		}
		catch(Exception e) {
			System.out.println("Problem 4 : "+e);
		}
		finally {
			System.out.println("Finally block is executed regardless of the exception....");
		}
		
		
		
		System.out.println("End of main.....");
		
	}

}

class MyCalculator
{
	public void divide(int x, int y) {
		
		System.out.println("x "+x);
		System.out.println("y "+y);
		System.out.println("Trying to divide "+x+" by "+y);
	
		/*
		if(y!=0) {
			int div = x / y; //our code/line is not prepared to catch the ArithmeticException
					//neither there is an error for such nor a mandate to catch it
			System.out.println("div is "+div);
		}
		else {
			System.out.println("Cannot divide by zero...");
		}
		*/
		
		
		int div = x / y; //our code/line is not prepared to catch the ArithmeticException
			//neither there is an error for such nor a mandate to catch it
		System.out.println("div is "+div);
		
		
		//what if there is a jungle / complex if conditions then???
		//how to handle the business or error logic section wise
		
		//thats why we write try { business logic }
		//catch() .... always error  handling logic
		System.out.println("Division is over..");
		System.out.println("---------");
	}
}
/*

	when the value of y is 0
	then JVM does the following logic.
	
	
	
	ArithmeticException arithEx new ArithmeticException("/ by zero");
	throw arithEx;
	
	
	
	

*/