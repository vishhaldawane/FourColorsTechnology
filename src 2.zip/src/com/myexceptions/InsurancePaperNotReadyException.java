package com.myexceptions;

public class InsurancePaperNotReadyException  extends Exception {
	public InsurancePaperNotReadyException(String str) {
		super(str);
	}
}
