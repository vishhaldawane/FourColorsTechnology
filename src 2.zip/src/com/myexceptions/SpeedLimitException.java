package com.myexceptions;

public class SpeedLimitException extends RuntimeException {
	public SpeedLimitException(String msg) {
		super(msg);
	}
}
