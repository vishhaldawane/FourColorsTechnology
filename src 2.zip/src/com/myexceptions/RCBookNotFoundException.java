package com.myexceptions;

public class RCBookNotFoundException  extends Exception {
	public RCBookNotFoundException(String str) {
		super(str);
	}
}
