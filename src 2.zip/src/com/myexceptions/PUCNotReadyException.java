package com.myexceptions;

public class PUCNotReadyException  extends Exception {
	public PUCNotReadyException(String str) {
		super(str);
	}
}
