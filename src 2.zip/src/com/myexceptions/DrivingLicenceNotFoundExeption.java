package com.myexceptions;

public class DrivingLicenceNotFoundExeption  extends Exception {
	public DrivingLicenceNotFoundExeption(String str) {
		super(str);
	}
}
