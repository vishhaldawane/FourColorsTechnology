package com.journey;


import com.myexceptions.*;

public class CarTest {

	public static void main(String[] args) {
		System.out.println("Begin of main...");

		//what if the driver's license is not there
		//what if the PUC is not ready
		//what if the insurance paper is not ready..
		//what if the rc book is not ready
		
		Car myCar = null;
		
		try {
			myCar = new Car(); //this line is verified by the compiler to handle the exception
		}
		catch(DrivingLicenceNotFoundExeption e) {
			System.out.println("Checked Problem 1 : "+e);
		}
		catch(PUCNotReadyException e) {
			System.out.println("Checked Problem 2 : "+e);
		}
		catch(InsurancePaperNotReadyException e) {
			System.out.println("Checked Problem 3 : "+e);
		}
		catch(RCBookNotFoundException e) {
			System.out.println("Checked Problem 4 : "+e);
		}
		catch(Exception e) {
			System.out.println("GEneric Checked Problem : "+e);
		}
		
		 // ==> at this line we have to handle the checked exceptions
		try {
			myCar.longDrive();   // <== inside this method code we are throwing unchecked exceptions....
		}
		
		catch(SpeedLimitException e) {
			System.out.println("Problem1 : "+e);
			System.out.println("handling speed limit related challan creation process...300Rs");
		}
		catch(LaneCrossedException e) {
			System.out.println("Problem2 : "+e);
			System.out.println("handling lane cross related challan creation process...100Rs");
		}
		catch(RedSignalDisHonouredException e) {
			System.out.println("Problem3 : "+e);
			System.out.println("handling red signal jumped related challan creation process...200Rs");
		}
		catch(NullPointerException e) {
			System.out.println("Car is NOT ready....");
		}
		catch(RuntimeException e) {
			System.out.println("Generic Problem : "+e);
			
		}
		
		System.out.println("End of main...");
	}

}
/*
 
 
 							Surgeon <--- RuntimeException
  								|
  				-------------------------------------------
  				|				|					|
  		HeartSurgeon		NeuroSurgeon		OrthoSurgeon
  
  
  
  
*/