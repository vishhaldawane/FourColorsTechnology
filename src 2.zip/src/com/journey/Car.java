package com.journey;

import com.myexceptions.*;

public class Car {
	
	public Car() throws Exception
	{
		System.out.println("Getting the Car ready....");
	
		double value = Math.random();
		
		if(value>0.90) {
			//Exception ex = new Exception("Driving licence is not ready...");
			DrivingLicenceNotFoundExeption ex = new DrivingLicenceNotFoundExeption("Driving licence is not ready...");
			throw ex;
		}
		else 
			if(value>0.80 && value<=0.85) {
				//Exception ex = new Exception("PUC book is not ready...");
				PUCNotReadyException ex = new PUCNotReadyException("PUC book is not ready...");
				throw ex;	
			}
			else 
				if(value>0.70 && value<=0.75) {
				//	Exception ex = new Exception("Insurance papers are not ready...");
					InsurancePaperNotReadyException ex = new InsurancePaperNotReadyException("Insurance papers are not ready...");
					
					throw ex;	
				}
				else 
					if(value>0.60 && value<=0.65) {
						//Exception ex = new Exception("RC Book is not ready...");
						RCBookNotFoundException ex = new RCBookNotFoundException("RC Book is not ready...");
						throw ex;	
					}
			
		System.out.println("1. RC book is ready...");
		System.out.println("2. Insurance papers area ready...");
		System.out.println("3. PUC  book is ready...");
		System.out.println("4. Driving Licence  is ready...");
		
		
		System.out.println("The Car is ready....");
		
	}
	
	public void longDrive() 
	{
		
		for(int i=1;i<=25;i++) {
			System.out.println("Car completed..."+i+" kms");
			double value = Math.random();
			
			if(value > 0.98) {
				//RuntimeException rte = new RuntimeException("Car has exceeded the speed limit...");
				SpeedLimitException rte = new SpeedLimitException("Car has exceeded the speed limit...");
				throw rte;
			}
			else if(value > 0.65 && value <0.66) {
				//RuntimeException rte = new RuntimeException("Car has crossed into wrong lane..");
				LaneCrossedException rte = new LaneCrossedException("Car has crossed into wrong lane..");
				
				throw rte;
			}
			else if(value > 0.25 && value <0.27) {
				//RuntimeException rte = new RuntimeException("Car has dishonoured the red signal..");
				RedSignalDisHonouredException rte = new RedSignalDisHonouredException("Car has dishonoured the red signal..");
				throw rte;
			} 

		}
	}

}
