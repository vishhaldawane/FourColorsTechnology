package com.fourcolors;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 
  
  	Food restaurant 
  	|
  	Governed by One Person - Jack
  	
  	1. Jack is the Order taker - Jack - Servlet [ C ONTROLLER ] - BL
  	2. Jack is the Chef - Jane,Anjali					[ M odel ] data - DL - DAO
  	3. Jack is the Presenter - Julie 			[ V IEW ] JSP   - PL
  	

Customer1		Customer2		Customer3		Customer4		Customer5
|				|				|				|				|
Pizza			Idli Sambar		Fried Rice		Paneer Chilly   Juice


table1		table2		table3			table4		table5
5			5			5				5			5		= 25 

100



DAO
	1. POJO - plain old java object [ similar to the table's structure ]
	2. POJO's CRUD interface
	3. Pojo's CRUD interface implementation
	
	class Department
	{
	
	}


*/
public class CrudServlet extends HttpServlet {
	
	Connection conn ;
	Statement  st ;
	ResultSet  result;
	
    public CrudServlet() {
    	System.out.println("CrudServlet() ctor...");
    }
    
	public void init(ServletConfig config) throws ServletException {
		try {
			//1	
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registerd....");			
			//2
			conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			System.out.println("Connected to the DB : "+conn);			
			//3
			st = conn.createStatement();System.out.println("Statement made "+st);	
		} catch (SQLException e) {e.printStackTrace();}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		
		
		
			String action = request.getParameter("submit"); //BL
			
			PrintWriter pw = response.getWriter();		//BL
			//pw.println(action+" invoked..."+deptno);
			
			response.setContentType("text/html"); //BL
			
			if(action.equals("Add")) { //BL
				pw.println("<h2>Adding New Department details </h2>"); //PL
				int newDeptno = Integer.parseInt(request.getParameter("deptno")); // BL
				String newDeptName = request.getParameter("deptname");	 //BL
				String newDeptLoc = request.getParameter("deptloc");	 //BL
			
				try {
					Statement st = conn.createStatement(); //DL
					ResultSet rs = st.executeQuery("select * from dept_fc where deptno="+newDeptno); //DL
					
					if(!rs.next()) { //DL
							
						PreparedStatement pst = conn.prepareStatement("insert into dept_Fc values (?,?,?)"); //DL
						pst.setInt(1, newDeptno); //DL
						pst.setString(2, newDeptName); //DL
						pst.setString(3, newDeptLoc); //DL
						
						System.out.println("PreparedStatement made "+pst); //DL
						
						int row = pst.executeUpdate(); //DL
						System.out.println(row+" row(s) inserted....."); //DL
						pw.println("<h3>Row Inserted "+row+" </h3>"); //PL
						pw.println("<a href='http://localhost:8080/JdbcWebProject/jdbc'>Go Back</a>"); //PL
					}
					else {
						pw.println("<h3>This Department Number Already Exists!!! "+newDeptno+" </h3>");
						pw.println("<a href='http://localhost:8080/JdbcWebProject/jdbc'>Go Back</a>");
					}
				}
				catch(SQLException e) {
					System.out.println("Inserting exception : "+e);
				}
				
			}
			else if(action.equals("Delete")) { //BL
				
				String deptno = request.getParameter("deptno");	 //BL
				
				pw.println("<h2>Deleting this department number "+deptno+" </h2>"); //PL
				
			
				int existingDeptno = Integer.parseInt(deptno);
				
				try {
					
					Statement st = conn.createStatement();
					ResultSet rs = st.executeQuery("select * from dept_fc where deptno="+existingDeptno);
					
					if(rs.next()) {
							
						
						PreparedStatement pst = conn.prepareStatement("delete from dept_Fc where deptno=?");
						pst.setInt(1, existingDeptno);
					
						System.out.println("PreparedStatement made "+pst);
					
						int row = pst.executeUpdate();
						System.out.println(row+" row(s) deleted.....");
						pw.println("<h3>Row Deleted "+deptno+" </h3>");
						pw.println("<a href='http://localhost:8080/JdbcWebProject/jdbc'>Go Back</a>");
					
					}
					else {
						pw.println("<h3>Row NOT Found  "+deptno+" </h3>");
						pw.println("<a href='http://localhost:8080/JdbcWebProject/jdbc'>Go Back</a>");
					}
				
					
					
					//RequestDispatcher rd = request.getRequestDispatcher("/jdbc");
					//rd.forward(request, response);
				}
				catch(SQLException e) {
					System.out.println("deleting exception : "+e);
				}
			}
			else if(action.equals("Edit")) {
				try
				{
					
					
					String deptno = request.getParameter("deptno");	
					pw.println("<h2>Editing this department number "+deptno+" </h2>");
					
	
					int existingDeptno = Integer.parseInt(deptno);
					
					Statement st = conn.createStatement();
					ResultSet rs = st.executeQuery("select * from dept_fc where deptno="+existingDeptno);
	
					
					if(rs.next()) {
						
					
						String modifiedDeptName = request.getParameter("deptname");	
	
						String modifiedDeptLoc = request.getParameter("deptloc");	
					
						PreparedStatement pst = conn.prepareStatement("update dept_Fc set deptname=?, deptloc=? where deptno=?");
				
						pst.setString(1, modifiedDeptName);
						pst.setString(2, modifiedDeptLoc);
						pst.setInt(3, existingDeptno);
					
						System.out.println("PreparedStatement made "+pst);
					
						int row = pst.executeUpdate();
						System.out.println(row+" row(s) updated.....");
						pw.println("<h3>Row Updated "+row+" </h3>");
						pw.println("<a href='http://localhost:8080/JdbcWebProject/jdbc'>Go Back</a>");
				
					}else {
						pw.println("<h3>Row NOT found  "+existingDeptno+" </h3>");
						pw.println("<a href='http://localhost:8080/JdbcWebProject/jdbc'>Go Back</a>");
				
					}
				}
				
				catch(SQLException e) {
					System.out.println("Modifing exception  "+e);
				}
				

			}

		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);    
	}

	
	public void destroy() {
		try {
			result.close();
			st.close();
			conn.close();
			DriverManager.deregisterDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("driver is de-registered....");
			System.out.println("Driver registerd....");		
			System.out.println("DB resources are closed.....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


