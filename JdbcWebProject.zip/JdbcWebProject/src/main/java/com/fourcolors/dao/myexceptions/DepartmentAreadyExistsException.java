package com.fourcolors.dao.myexceptions;

public class DepartmentAreadyExistsException extends /*Runtime*/Exception {

	public DepartmentAreadyExistsException(String str) {
		super(str);
	}
}


//open bank account				vs			withdraw money from atm