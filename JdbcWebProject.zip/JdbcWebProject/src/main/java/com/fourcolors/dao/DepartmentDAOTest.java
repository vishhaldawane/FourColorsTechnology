package com.fourcolors.dao;

import java.util.List;

import com.fourcolors.dao.myexceptions.DepartmentNotFoundException;

public class DepartmentDAOTest {

	public static void main(String[] args) { //Mom
		
		

		//Mom -> Maid -> maid has prepared the idli - she has to keep them ready in the steamer
		
		DepartmentDAOImpl deptDao = new DepartmentDAOImpl(); //maid
		
	
		try {
			deptDao.deleteDepartment(90);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //try catch is not mandatory for unchecked exceptions
		 
		
	//	Department dept = new Department();
	//	dept.setDepartmentNumber(50);
	//	dept.setDepartmentName("Mymovie");
	//	dept.setDepartmentLocation("Thrill");
		
	//	deptDao.updateDepartment(dept);
		
		//Department department = deptDao.selectDepartment(101);
		//System.out.println("Dept Number   : "+department.getDepartmentNumber());
		//System.out.println("Dept Name     : "+department.getDepartmentName());
		//System.out.println("Dept Location : "+department.getDepartmentLocation());
		
		
		//List<Department> deptList = deptDao.selectDepartments();
		
		
		//System.out.println("Dept list size : "+ deptList.size());
		
		
//		List<Department> deptList = deptDao.selectDepartments();
//		
//		for (Department department : deptList) {
//			System.out.println("Dept Number   : "+department.getDepartmentNumber());
//			System.out.println("Dept Name     : "+department.getDepartmentName());
//			System.out.println("Dept Location : "+department.getDepartmentLocation());
//			System.out.println("------------------");
//		}
		

	}

}
