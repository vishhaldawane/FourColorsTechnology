import java.time.LocalDate;

public class PanCard {
	private String panNumber;
	private String fatherName;
	private LocalDate dateOfBirth;
	private String issuedBy;
	
	public void setPanCard(String panNumber, String fatherName, LocalDate dateOfBirth, String issuedBy) {
	
		this.panNumber = panNumber;
		this.fatherName = fatherName;
		this.dateOfBirth = dateOfBirth;
		this.issuedBy = issuedBy;
	}
	
	void showPanCardDetails() {
		System.out.println("+------Pan Card Details------+");
		System.out.println("| Pan Number    : "+panNumber+" |");
		System.out.println("| Father Name   : "+fatherName+" |");
		System.out.println("| Date of Birth : "+dateOfBirth+" |");
		System.out.println("| Pan Issued By : "+issuedBy+" |");
		System.out.println("+----------------------------+");
	}
}
