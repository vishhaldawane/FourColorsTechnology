package com.myexceptions;

public class LaneCrossedException extends RuntimeException {
	public LaneCrossedException(String msg) {
		super(msg);
	}
}
