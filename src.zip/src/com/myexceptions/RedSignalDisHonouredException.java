package com.myexceptions;

public class RedSignalDisHonouredException extends RuntimeException {
	public RedSignalDisHonouredException(String msg) {
		super(msg);
	}
}
