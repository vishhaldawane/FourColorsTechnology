package com.journey;

import com.myexceptions.LaneCrossedException;
import com.myexceptions.RedSignalDisHonouredException;
import com.myexceptions.SpeedLimitException;

public class CarTest {

	public static void main(String[] args) {
		System.out.println("Begin of main...");

		Car myCar = new Car();
		
		try {
			myCar.longDrive();
		}
		catch(SpeedLimitException e) {
			System.out.println("Problem : "+e);
		}
		catch(LaneCrossedException e) {
			System.out.println("Problem : "+e);
		}
		catch(RedSignalDisHonouredException e) {
			System.out.println("Problem : "+e);
		}
		
		System.out.println("End of main...");
	}

}
