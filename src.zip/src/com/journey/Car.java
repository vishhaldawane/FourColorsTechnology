package com.journey;

import com.myexceptions.LaneCrossedException;
import com.myexceptions.RedSignalDisHonouredException;
import com.myexceptions.SpeedLimitException;

public class Car {
	
	public void longDrive() {
		
		for(int i=1;i<=25;i++) {
			System.out.println("Car completed..."+i+" kms");
			double value = Math.random();
			
			if(value > 0.98) {
				//RuntimeException rte = new RuntimeException("Car has exceeded the speed limit...");
				SpeedLimitException rte = new SpeedLimitException("Car has exceeded the speed limit...");
				throw rte;
			}
			else if(value > 0.65 && value <0.66) {
				//RuntimeException rte = new RuntimeException("Car has crossed into wrong lane..");
				LaneCrossedException rte = new LaneCrossedException("Car has crossed into wrong lane..");
				
				throw rte;
			}
			else if(value > 0.25 && value <0.27) {
				//RuntimeException rte = new RuntimeException("Car has dishonoured the red signal..");
				RedSignalDisHonouredException rte = new RedSignalDisHonouredException("Car has dishonoured the red signal..");
				throw rte;
			} 

		}
	}

}
