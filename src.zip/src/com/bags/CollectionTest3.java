package com.bags;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;


public class CollectionTest3 {
	public static void main(String[] args) {
	
		
		Song s1 = new Song("My Heart Will Go On", "Celine D", "Titanic", 1996);
		Song s2 = new Song("Zhingat", "Ajay Atul", "Sairat", 2016);
		Song s3 = new Song("I want it that way","Backstreet Boys", "Backstreet Boys", 1998);
		Song s4 = new Song("Kolavari", "Dhanush", "3", 2014);
		Song s5 = new Song("Lungi Dance", "Honey Singh","Chennai Express", 2019);
		
		Collection  collection = new ArrayList();//growable array - Elevator
		//Collection  collection = new LinkedList();//growable array - StairCases
		//Collection  collection = new TreeSet(); // colony of apartments, wing A , Wing B
		//Collection  collection = new HashSet();
		
		System.out.println("Container is ready....");
		//8  3  10 1  6  14  4  7  13
		
		System.out.println("Trying to add Content to the Container...");
		collection.add(s1);
		collection.add(s2);
		collection.add(s3);
		collection.add(s4);
		collection.add(s5);
		
		System.out.println("Content is added to the container....");
		
		System.out.println("Trying to acquire the Iterator....from the Cotnainer...");
		
		Iterator iter = collection.iterator();
		
		while(iter.hasNext()) {
			Song theSong = (Song) iter.next();
			System.out.println("Song is : "+theSong);
		}
		
		System.out.println("End of main...");
		
		
	}
}


/*

Fort - Girnar   Ropeway 8 -> 700   - Helipad  - Doli Palaki
 Steps   	
 
 Ready framework = semi-developed application
 
					Iterable
					    |  Iterator iterator();
						|
					Collection
						|  void add(Object o);
						|
				-------------------
				|				|
			   List				Set
			   |linear			 |non-linear
			   |duplicates		 | unique
	------------------			-------------
	  |			   |			|			|
	ArrayList	LinkedList	TreeSet		 HashSet <-- containers

growable array
   +----+
0  | 5  |
   +----+
1  | 7  |
   +----+
2  | 9  |
   +----+
3  |  4 |
   +----+
4  | 3  |
   +----+
5  | 1  |
   +----+
6  |    |


5 7 9 4 3 1

    ^ <--appends at the end of it...fastest to append
   /|\			faster search.....
	|	for storing logs type of data
	
	PhoneLog
	
			node1			node2			node3			node4
			+-------+		+-------+		+-------+		+-------+
			|n   150| --->	|n	50	| --->	|n	300	| --->	|n	  0	| 
			|500	|		|700	|		|	200	|		|	400	|
			|0	p	| <---	|10	p	| <---	|150 p	| <---	|50	p	| 
			+-------+		+-------+		+-------+		+-------+
			10				150				50				300
			
			
			500	----------------> phoneNumber	emailAddress   contactName
			PhoneContact
			
			700	----------------> phoneNumber	emailAddress   contactName
			PhoneContact
			
			200	----------------> phoneNumber	emailAddress   contactName
			PhoneContact
			
			400	----------------> phoneNumber	emailAddress   contactName
			PhoneContact
			
			
			
			8  3  10 1  6  14  4  7  13 <-- in order
			
			1  3  4  6  7  8   10  13  14 <-- out order is sorted
			
						Binary Tree
						
							   8 <--root
							   |
						-------------
						|l			|r
						3			10
						|			|
					---------	  -------
					|l	    |r	  |l	|r
					1		6			14
							|			|
						--------	---------
						|l		|r	|l		r
						4		7	13
						
						
						Book Shelf <- HashSet
	

				+---------------------------------------+
				|	comics		|			| science	|
				|				|			|			|
				----------------+			|			|
				|			    |			|			|
				|	novel		|			+-----------+
				|				|	motiva	|	fiction	|
				|				|	tional	|			|
				+---------------+-----------+-----------+
				|	magz		|			| textbooks	|
				|				|	bio-	|			|
				----------------+	graphies|			|
				|	spiritual   |			|			|
				|				|			+-----------+
				|				|			| stories	|
				|				|			|			|
				+---------------------------------------+
	
	Autobiography of a Yogi
	
	
	
*/




