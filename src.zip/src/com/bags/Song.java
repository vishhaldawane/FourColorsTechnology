package com.bags;

public class Song
{
	String title;
	String artst;
	String album;
	int year;
	public Song(String title, String artst, String album, int year) {
		super();
		this.title = title;
		this.artst = artst;
		this.album = album;
		this.year = year;
	}
	@Override
	public String toString() {
		return "Song [title=" + title + ", artst=" + artst + ", album=" + album + ", year=" + year + "]";
	}
	
	
}