package com.bags;

public class CollectionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//WaterBottle schoolBottle = new WaterBottle();  label - name-std-div-roll
		

		EggContainer eggContainer = new EggContainer(24);
		
		eggContainer.add("Egg1");
		eggContainer.add("Egg2");
		eggContainer.add(null);
		eggContainer.add("Egg4");
		eggContainer.add("Egg5");
		eggContainer.add("Egg6");
//		eggContainer.add("Egg7");
//		eggContainer.add("Egg8");
//		eggContainer.add("Egg9");
//		eggContainer.add("Egg10");
//		eggContainer.add("Egg11");
//		eggContainer.add("Egg12");
		
		//eggContainer.add("Egg13");
		System.out.println("------------------");
		MyIterator iter = eggContainer.myIterator();
		System.out.println("Got the iterator..."+iter);
		
		while(iter.hasNext()) {
			String str = (String) iter.next();
			System.out.println("Egg : "+str);
		}
		
		
		
		BottleContainer bottle = new BottleContainer(12); //12 means 120 ml bottle   250  500ml   750ml  1000ml
		
		bottle.add("10ml");
		bottle.add("20ml");
		bottle.add("30ml");
		
		bottle.add("40ml");
		bottle.add("50ml");
		bottle.add("60ml");
		
		bottle.add("70ml");
		bottle.add("80ml");
		bottle.add("90ml");
		
		bottle.add("100 ml");
		bottle.add("110 ml");
		bottle.add("120 ml");
		
		MyIterator bIter = bottle.myIterator();
		while(bIter.hasNext()) {
			String str = (String) bIter.next();
			System.out.println("str "+str);
		}

	}

}





interface Laughing
{
	void laugh();
}

interface Joking
{
	Laughing makeJoke();
}

class Joker implements Joking
{
	public Laughing makeJoke() {//must produce a Laughing implementation
		Laughing laughing = new BellyLaughter();
		return laughing;
	}
	
	//nested classes - class within a class 
	private class HorseLaughter implements Laughing
	{
		public void laugh()
		{
			System.out.println("a loud laugh that sounds like a horse neighing...");
		}
	}
	private class BellyLaughter implements Laughing
	{
		public void laugh()
		{
			System.out.println("the burst of deep loud hearty laughter.....");
		}
	}

}

interface MyIterator //   elevator, "straicases, train-compartments", 
					//mango tree,    booklibrary
{
	boolean hasNext();
	Object next();
}

//implementation of MyIterator means the class who implements this interface
//e.g. EggIterator, Straw


interface MyIterable //
{
	MyIterator myIterator(); //producing the MyIterator
	
}

abstract class MyContainer implements MyIterable
{
	abstract void add(Object o);
}

//implementation of MyIterable means the class who implements this interface
//e.g. MyIterable ( EggContainer, BottleContainer )

//implementation of MyContainer means the class who extends this abstract class
//e.g. MyContainer ( EggContainer, BottleContainer )



class EggContainer extends MyContainer //will it have a size
{
	final int CAPACITY; // 0 to 11 = 12
	Object objectArray[] = null;  // to hold 12 objects
	int index=-1;
	
	EggContainer(int initialCapacity) {
		CAPACITY = initialCapacity;
		objectArray = new  Object[CAPACITY];
	}
	void add(Object obj) {//mandate from MyContainer
		
		if(index >= CAPACITY-1) {
			EggContainerCapacityExhaustedException ecceEx = new EggContainerCapacityExhaustedException("Egg container capacity is exahusted....");
			throw ecceEx;
		}
		objectArray[++index] = obj;
		System.out.println("adding...at "+index);
		
	}
	
	
//	MyIterator implemented BELOW - nested class
	private class EggIterator implements MyIterator
	{
		int initialIndex = 0;
		boolean isItEmpty=true;
		
		public boolean hasNext() {
			
		//	if(objectArray[initialIndex]==null) {
		//		return false;
		//	}
			
			if(initialIndex < objectArray.length)
				return true;
			else
				return false;
		}
		
		public Object next() { //would be called 12 times
			if(this.hasNext()) {
				return objectArray[initialIndex++];
			}
			return null;
		} 
	}
	
	public 	MyIterator myIterator() //mandate from MyIterable
	{
		EggIterator eggIter = new EggIterator(); //object of the private class here
		return eggIter; //returning it...
	}
}

class BottleContainer extends MyContainer //will it have a size
{
	final int CAPACITY; // 0 to 11 = 12
	Object objectArray[] = null;  // to hold 12 objects
	int index=-1;
	
	BottleContainer(int initialCapacity) {
		CAPACITY = initialCapacity;
		objectArray = new  Object[CAPACITY];
	}
	void add(Object obj) {
		
		if(index >= CAPACITY-1) {
			BottleContainerCapacityExhaustedException ecceEx = new BottleContainerCapacityExhaustedException("Bottle container capacity is exahusted....");
			throw ecceEx;
		}
		objectArray[++index] = obj;
		System.out.println("adding...at "+index);
		
	}
	
	
//	MyIterator implemented BELOW
	private class Straw implements MyIterator
	{
		int initialIndex = 0;
		boolean isItEmpty=true;
		
		public boolean hasNext() {
			
		//	if(objectArray[initialIndex]==null) {
		//		return false;
		//	}
			
			if(initialIndex < objectArray.length)
				return true;
			else
				return false;
		}
		
		public Object next() { //would be called 12 times
			if(this.hasNext()) {
				return objectArray[initialIndex++];
			}
			return null;
		} 
	}
	public 	MyIterator myIterator()
	{
		Straw theStraw = new Straw(); //object of the private class here
		return theStraw; //returning it...
	}
}

class EggContainerCapacityExhaustedException extends RuntimeException
{
	EggContainerCapacityExhaustedException(String str) {
		super(str);
	}
}
class BottleContainerCapacityExhaustedException extends RuntimeException
{
	BottleContainerCapacityExhaustedException(String str) {
		super(str);
	}
}

interface Drawing
{
	Art draw();
}


interface Art
{
	void erase();
	void drawBorder();
	void freeDraw();
}

				/*
				 			Art    <================      Drawing
				 			|								|
				 	------------------					------------------
				 	|				|					|			  |
				 	MadhubaniArt	PortraitArt	  MadhubaniAritst  PortraitArtist
				 									draw() { }			draw() { }
				 		
				  
				 */

class MadhubaniArt implements Art
{
	public void erase() { } //erase unwanted contents ....sometimes 
	public void drawBorder() { } // draw a border 
	public void freeDraw() { } //ur own skill of draw...
}

class PortraitArt implements Art
{
	public void erase() { } //erase unwanted shadows... ....sometimes 
	public void drawBorder() { } // draw a border 
	public void freeDraw() { } //ur own skill of draw...the face..add shadows...
}

abstract class Artist 
{
	
}

class MadhubaniArtist extends Artist implements Drawing
{
	public Art draw() {
		MadhubaniArt myArt = new MadhubaniArt();
		
		return myArt; // may be  canvas of this size;
	}
}

class PortraitArtist extends Artist implements Drawing
{
	public Art draw() {
		
		PortraitArt portrait = new PortraitArt();
		return portrait; // may be  canvas of this size;
	}
}




