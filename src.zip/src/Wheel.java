
public class Wheel {

	private String company; //JK tyre Appolo MRF CEAT
	private String type; // mac wheel alloyed wheel
	private float size; // 4.3  4.5
	private float airPressure; // 
	
	public void setWheel(String company, String type, float size,float ap) {
		
		this.company = company;
		this.type = type;
		this.size = size;
		this.airPressure= ap;
	}
	
	void showWheel() {
		System.out.println("---------------");
		System.out.println("Wheel Company : "+company);
		System.out.println("Wheel Type    : "+type);
		System.out.println("Wheel Size    : "+size);
		System.out.println("Wheel Air     : "+airPressure+" Units");
	}
	
	
}
