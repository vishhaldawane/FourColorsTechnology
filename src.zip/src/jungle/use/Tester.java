package jungle.use;

import jungle.tree.Monkey;

public class Tester {

	public static void main(String[] args) {
		System.out.println("Begin main...");
		
		Monkey mon = new Monkey();
		mon.jump();
		Gorilla gor = new Gorilla();
		
		System.out.println("End main...");
		
	}

}
class Sparrow {
	void fly() {
		Monkey m = new Monkey();
		m.defAge=12;
		m.pubAge=13;
		m.priAge=14;//error
		m.proAge=15;
	}
}
class Gorilla extends Monkey {
	Gorilla() {
		super();
	}
	void gigling() {
		System.out.println("Gorilla is gigling...");
		jump(); //will search in the current class and then in the super class
		System.out.println("defAge "+defAge);
		System.out.println("pubAge "+pubAge);
		System.out.println("priAge "+priAge);
		System.out.println("proAge "+proAge);
		
	}
}
