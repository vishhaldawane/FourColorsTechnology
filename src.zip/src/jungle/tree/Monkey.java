package jungle.tree;

public class Monkey {
	
	int 	   defAge;//1.package based access[child/non-child]] can access the default
	//2.non-package based child[Gorilla] canNOT access the default
	//3.non-package based non-child[Sparrow] canNOT access the default 
	
	public int pubAge;//internet

	private int priAge;//within the same class body

	protected int proAge;//1.package based non-child can access the protected
	//2.package based child can access the protected
	//3.non-package based non-child canNOT accessthe protected
	
	
	public Monkey() {
		System.out.println("Monkey ctor...");
	}
	public void jump() {
		System.out.println("Monkey is jumping....");
	}

}
class Bird { //non-child
	void fly() {
		Monkey m = new Monkey();
		m.defAge=12;
		m.pubAge=13;
		m.priAge=14;//error
		m.proAge=15;
	}
}
class Chimp extends Monkey { //non-child

	int swingLength; //5th data member
	
	Chimp() {
		super(); //Monkey() ctor...
	}
//	public void jump() {
//		
//	}
	void swing() {
		jump(); //will search in the current class and then in the super class
		System.out.println("defAge "+defAge);
		System.out.println("pubAge "+pubAge);
		System.out.println("priAge "+priAge);
		System.out.println("proAge "+proAge);
		
		
		/*Monkey m = new Monkey();
		m.defAge=12;
		m.pubAge=13;
		m.priAge=14;//error
		m.proAge=15;*/
	}
}
