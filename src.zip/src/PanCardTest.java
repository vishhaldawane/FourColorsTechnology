import java.time.LocalDate;

public class PanCardTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Person person = new Person('M',23,"Suraj Dev");
		
		person.panCard.setPanCard("AJGTD3312E", "Tejas  Dev", LocalDate.of(1999, 1, 12), "Govt OfInd");
		person.savObj.setInitialValues(101, "Suraj Dev",50000,4.5f);
		person.showPersonDetails();
		
		
	}

}
