
/*
 * 
 * 
 * Wheel is a Car
 * or
 * Car is a Wheel
 * 
 * Car hasA Wheel
 * 
 */
public class HasATest {

	public static void main(String[] args) {
		
		Car myCar1 = new Car("Swift",2014,"Petrol",15.5f,54000);
		myCar1.frontLeftWheel.setWheel("MRF","Alloyed",4.3f,32.0f);
		myCar1.frontRightWheel.setWheel("MRF","Alloyed",4.3f,32.0f);
		myCar1.rearLeftWheel.setWheel("MRF","Alloyed",4.3f,33.0f);
		myCar1.rearRightWheel.setWheel("MRF","Alloyed",4.3f,33.0f);

		myCar1.showCarDetails();
		
		System.out.println("=========================");
		
		Car myCar2 = new Car("Honda City",2018,"Petrol",10.5f,14000);
		myCar2.frontLeftWheel.setWheel("CEAT","Mac",4.1f,30.0f);
		myCar2.frontRightWheel.setWheel("CEAT","Mac",4.1f,30.0f);
		myCar2.rearLeftWheel.setWheel("CEAT","Mac",4.1f,32.0f);
		myCar2.rearRightWheel.setWheel("CEAT","Mac",4.1f,32.0f);

		
		myCar2.showCarDetails();
		
		System.out.println("=========================");
		
		
		Car myCar3 = new Car("Camry",2020,"Hybrid",12.5f,4000);
		myCar3.frontLeftWheel.setWheel("JK Tyre","Mac",4.0f,30.0f);
		myCar3.frontRightWheel.setWheel("JK Tyre","Mac",4.0f,30.0f);
		myCar3.rearLeftWheel.setWheel("JK Tyre","Mac",4.0f,31.0f);
		myCar3.rearRightWheel.setWheel("JK Tyre","Mac",4.0f,31.0f);

		myCar3.showCarDetails();
		
		
		
	}
}






