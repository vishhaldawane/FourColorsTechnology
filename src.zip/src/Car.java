
public class Car {
	
	String model; // Swift, Honda, Toyota
	int year;
	String fuelType;
	float average;
	long kilometersDrivenTillNow;
	
	Wheel frontLeftWheel = new Wheel(); //as a part of the Car it is here   32
	Wheel frontRightWheel = new Wheel();		//32
	Wheel rearLeftWheel = new Wheel();  	//33
	Wheel rearRightWheel = new Wheel();     //33
	
	public Car(String model, int year, String fuelType, float average, long kilometersDrivenTillNow) {
		super();
		this.model = model;
		this.year = year;
		this.fuelType = fuelType;
		this.average = average;
		this.kilometersDrivenTillNow = kilometersDrivenTillNow;
		
		/*frontLeftWheel.setWheel("MRF","Alloyed",4.3f);
		frontRightWheel.setWheel("MRF","Alloyed",4.3f);
		rearLeftWheel.setWheel("MRF","Alloyed",4.3f);
		rearRightWheel.setWheel("MRF","Alloyed",4.3f);*/
	}
	
	void showCarDetails() {
		System.out.println("Car Model   : "+model);
		System.out.println("Car Year    : "+year);
		System.out.println("Car Fuel    : "+fuelType);
		System.out.println("Car Average : "+average);
		System.out.println("Car Kms     : "+kilometersDrivenTillNow);
		
		frontLeftWheel.showWheel();
		frontRightWheel.showWheel();
		rearLeftWheel.showWheel();
		rearRightWheel.showWheel();
		
	}
	
	

}
/*
class LimousineCar extends Car
{
	Wheel frontLeftWheel1 = new Wheel(); //as a part of the Car it is here   32
	Wheel frontRightWheel1 = new Wheel();		//32
	Wheel rearLeftWheel1 = new Wheel();  	//33
	Wheel rearRightWheel1 = new Wheel();     //33
	
	
}*/
