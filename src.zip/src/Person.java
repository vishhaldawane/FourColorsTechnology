
public class Person { //WHOLE entity

	char gender;
	int age;
	String name;
	
	PanCard panCard = new PanCard(); //hasA - PART entity of the WHOLE
	SavingsAccount savObj = new SavingsAccount(); // USER ROLE!!!
	
	
	
	
	public Person(char gender, int age, String name) {
		super();
		this.gender = gender;
		this.age = age;
		this.name = name;
	}
	
	void showPersonDetails() {
		System.out.println("+------Personal Details------+");
		System.out.println("| Gender        : "+gender+"          |");
		System.out.println("| Age           : "+age+"         |");
		System.out.println("| Name          : "+name+"  |");
		System.out.println("+----------------------------+");
		panCard.showPanCardDetails();
		savObj.showAccountDetails();
	}
}
